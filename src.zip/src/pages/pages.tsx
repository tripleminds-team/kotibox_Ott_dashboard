import { useState } from "react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { Edit, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import {
  useGetPages,
  useUpdatePage,
  useDeletePage,
  useBulkDeletePages,
} from "@/lib/api-client";

type PageRow = {
  _id: string;
  title: string;
  slug: string;
  status: string;
  order: number;
  createdAt: string;
  updatedAt: string;
};

export default function PagesPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [selectedPageIds, setSelectedPageIds] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const { data: pagesData, isLoading } = useGetPages({ page: currentPage, limit: itemsPerPage });
  const deleteMutation = useDeletePage();
  const updateMutation = useUpdatePage();
  const bulkDeleteMutation = useBulkDeletePages();

  const pages: PageRow[] = pagesData?.data || [];
  const pagination = pagesData?.pagination || { page: 1, limit: 10, total: 0, pages: 1 };

  // Filter pages by search query
  const filteredPages = pages.filter(page => 
    page.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleToggleActive = async (page: PageRow) => {
    try {
      const newStatus = page.status === "published" ? "draft" : "published";
      await updateMutation.mutateAsync({ id: page._id, data: { status: newStatus } });
      queryClient.invalidateQueries({ queryKey: ["pages"] });
      toast({ title: `Page ${newStatus === "published" ? "activated" : "deactivated"} successfully!` });
    } catch (error) {
      toast({ title: "Something went wrong", variant: "destructive" });
    }
  };

  const handleDelete = async (page: PageRow) => {
    if (!window.confirm(`Delete "${page.title}"?`)) {
      return;
    }

    try {
      setDeletingId(page._id);
      await deleteMutation.mutateAsync(page._id);
      toast({ title: "Page deleted successfully!" });
    } catch (error) {
      toast({ title: "Delete failed", variant: "destructive" });
    } finally {
      setDeletingId(null);
    }
  };

  const handleBulkDelete = async () => {
    if (selectedPageIds.length === 0) {
      toast({ title: "No pages selected", variant: "destructive" });
      return;
    }

    if (!window.confirm(`Delete ${selectedPageIds.length} page(s)?`)) {
      return;
    }

    try {
      await bulkDeleteMutation.mutateAsync(selectedPageIds);
      setSelectedPageIds([]);
      toast({ title: "Pages deleted successfully!" });
    } catch (error) {
      toast({ title: "Bulk delete failed", variant: "destructive" });
    }
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    setSelectedPageIds([]);
  };

  const handleItemsPerPageChange = (value: string) => {
    setItemsPerPage(parseInt(value));
    setCurrentPage(1);
    setSelectedPageIds([]);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
        <span className="text-white">Dashboard</span>
        <span>/</span>
        <span className="text-white">Pages</span>
      </div>

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <Select defaultValue="all" value={selectedPageIds.length > 0 ? "delete" : "all"} onValueChange={(value) => value === "delete" && handleBulkDelete()}>
            <SelectTrigger className="w-[180px] bg-zinc-800 border-zinc-700">
              <SelectValue placeholder="Action" />
            </SelectTrigger>
            <SelectContent className="bg-zinc-800 border-zinc-700">
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="delete" disabled={selectedPageIds.length === 0}>Delete Selected ({selectedPageIds.length})</SelectItem>
            </SelectContent>
          </Select>
          <Button 
            className="bg-gradient-to-r from-red-700 to-red-500 hover:from-red-800 hover:to-red-600"
            onClick={handleBulkDelete}
            disabled={selectedPageIds.length === 0 || bulkDeleteMutation.isPending}
          >
            Apply
          </Button>
        </div>
        <div className="flex items-center gap-4">
          <Select defaultValue="all">
            <SelectTrigger className="w-[140px] bg-zinc-800 border-zinc-700">
              <SelectValue placeholder="All" />
            </SelectTrigger>
            <SelectContent className="bg-zinc-800 border-zinc-700">
              <SelectItem value="all">All</SelectItem>
            </SelectContent>
          </Select>
          <div className="relative">
            <svg className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <circle cx="11" cy="11" r="8" />
              <path d="m21 21-4.35-4.35" />
            </svg>
            <Input 
              placeholder="Search..." 
              className="pl-10 bg-zinc-800 border-zinc-700" 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button 
            className="bg-gradient-to-r from-red-700 to-red-500 hover:from-red-800 hover:to-red-600 gap-2"
            onClick={() => setLocation("/pages/new")}
          >
            <Plus className="h-4 w-4" />
            New
          </Button>
        </div>
      </div>

      <div className="bg-zinc-800/50 rounded-lg overflow-hidden border border-zinc-700">
        {isLoading ? (
          <div className="py-12 text-center text-muted-foreground">Loading pages...</div>
        ) : pages.length === 0 ? (
          <div className="py-12 text-center">
            <p className="text-muted-foreground mb-4">No pages yet</p>
          </div>
        ) : (
          <Table>
            <TableHeader className="bg-zinc-800">
              <TableRow className="border-zinc-700 hover:bg-zinc-800">
                <TableHead className="w-12">
                  <Checkbox 
                    checked={filteredPages.length > 0 && selectedPageIds.length === filteredPages.length} 
                    onCheckedChange={(checked) => 
                      setSelectedPageIds(checked ? filteredPages.map(p => p._id) : [])
                    } 
                  />
                </TableHead>
                <TableHead className="text-white font-semibold">Name</TableHead>
                <TableHead className="text-white font-semibold text-right flex items-center justify-end gap-1">
                  <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M7.41 8.59 12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41Z"/>
                  </svg>
                  Status
                </TableHead>
                <TableHead className="text-white font-semibold text-right flex items-center justify-end gap-1">
                  <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M7.41 8.59 12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41Z"/>
                  </svg>
                  Action
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredPages.map((page) => {
                return (
                  <TableRow key={page._id} className="border-zinc-700 hover:bg-zinc-800/50">
                    <TableCell>
                      <Checkbox 
                        checked={selectedPageIds.includes(page._id)}
                        onCheckedChange={(checked) => 
                          setSelectedPageIds(prev => 
                            checked 
                              ? [...prev, page._id] 
                              : prev.filter(id => id !== page._id)
                          )
                        }
                      />
                    </TableCell>
                    <TableCell className="font-medium">
                      {page.title}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end">
                        <Switch 
                          checked={page.status === "published"} 
                          onCheckedChange={() => handleToggleActive(page)} 
                        />
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="bg-green-700 hover:bg-green-800 h-8 w-8"
                          onClick={() => setLocation(`/pages/${page._id}`)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="bg-amber-700 hover:bg-amber-800 h-8 w-8"
                        >
                          <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path d="m18 9-3.86 2.32-.64 1.93 2.5 1.5v2.5L12 15.45 7.99 17.25V14.75l2.5-1.5-.64-1.93L6 9h6l1.5-4.5h.99l.01 4.5H18z"/>
                          </svg>
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="bg-red-700 hover:bg-red-800 h-8 w-8"
                          onClick={() => handleDelete(page)}
                          disabled={deleteMutation.isPending || deletingId === page._id}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        )}
        {!isLoading && filteredPages.length > 0 && (
          <div className="px-6 py-4 flex items-center justify-between text-muted-foreground text-sm border-t border-zinc-700">
            <div className="flex items-center gap-2">
              <span>Show</span>
              <Select value={itemsPerPage.toString()} onValueChange={handleItemsPerPageChange}>
                <SelectTrigger className="w-[100px] bg-zinc-800 border-zinc-700 h-8">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-zinc-800 border-zinc-700">
                  <SelectItem value="10">10</SelectItem>
                  <SelectItem value="25">25</SelectItem>
                  <SelectItem value="50">50</SelectItem>
                </SelectContent>
              </Select>
              <span>entries</span>
            </div>
            <div className="flex items-center gap-2">
              <span>Showing {((pagination.page - 1) * pagination.limit) + 1} to {Math.min(pagination.page * pagination.limit, pagination.total)} of {pagination.total} entries</span>
              <Button 
                variant="ghost" 
                size="sm" 
                className="bg-zinc-800 border-zinc-700 h-8"
                onClick={() => handlePageChange(pagination.page - 1)}
                disabled={pagination.page === 1}
              >
                Previous
              </Button>
              {Array.from({ length: Math.min(pagination.pages, 5) }, (_, i) => {
                const pageNum = i + 1;
                return (
                  <Button
                    key={pageNum}
                    variant="ghost"
                    size="sm"
                    className={pageNum === pagination.page ? "bg-gradient-to-r from-red-700 to-red-500 hover:from-red-800 hover:to-red-600 h-8" : "bg-zinc-800 border-zinc-700 h-8"}
                    onClick={() => handlePageChange(pageNum)}
                  >
                    {pageNum}
                  </Button>
                );
              })}
              <Button 
                variant="ghost" 
                size="sm" 
                className="bg-zinc-800 border-zinc-700 h-8"
                onClick={() => handlePageChange(pagination.page + 1)}
                disabled={pagination.page === pagination.pages}
              >
                Next
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
