import { useState } from "react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { Edit, Plus, Trash2, Film } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import {
  useDeleteCategory,
  useBulkDeleteCategories,
  useGetCategoriesList,
} from "@/lib/api-client";

type CategoryRow = {
  id: string;
  name: string;
  description?: string;
  active: boolean;
  contentCount: number;
  createdAt: string;
  updatedAt: string;
};

export default function CategoriesPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [selectedCategoryIds, setSelectedCategoryIds] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const { data: categoriesData, isLoading } = useGetCategoriesList({ admin: true, page: currentPage, limit: itemsPerPage });
  const deleteMutation = useDeleteCategory();
  const bulkDeleteMutation = useBulkDeleteCategories();

  const categories: CategoryRow[] = categoriesData?.data || [];
  const pagination = categoriesData?.pagination || { page: 1, limit: 10, total: 0, pages: 1 };

  const handleDelete = async (category: CategoryRow) => {
    if (!window.confirm(`Delete "${category.name}"?`)) {
      return;
    }

    try {
      setDeletingId(category.id);
      await deleteMutation.mutateAsync(category.id);
      toast({ title: "Category deleted successfully!" });
    } catch (error) {
      toast({ title: "Delete failed", variant: "destructive" });
    } finally {
      setDeletingId(null);
    }
  };

  const handleBulkDelete = async () => {
    if (selectedCategoryIds.length === 0) {
      toast({ title: "No categories selected", variant: "destructive" });
      return;
    }

    if (!window.confirm(`Delete ${selectedCategoryIds.length} category(ies)?`)) {
      return;
    }

    try {
      await bulkDeleteMutation.mutateAsync(selectedCategoryIds);
      setSelectedCategoryIds([]);
      toast({ title: "Categories deleted successfully!" });
    } catch (error) {
      toast({ title: "Bulk delete failed", variant: "destructive" });
    }
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    setSelectedCategoryIds([]);
  };

  const handleItemsPerPageChange = (value: string) => {
    setItemsPerPage(parseInt(value));
    setCurrentPage(1);
    setSelectedCategoryIds([]);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Categories</h1>
          <p className="text-muted-foreground mt-1">
            {pagination.total} total
          </p>
        </div>
        <div className="flex items-center gap-4">
          <Select defaultValue="all" value={selectedCategoryIds.length > 0 ? "delete" : "all"} onValueChange={(value) => value === "delete" && handleBulkDelete()}>
            <SelectTrigger className="w-[180px] bg-zinc-800 border-zinc-700">
              <SelectValue placeholder="Action" />
            </SelectTrigger>
            <SelectContent className="bg-zinc-800 border-zinc-700">
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="delete" disabled={selectedCategoryIds.length === 0}>Delete Selected ({selectedCategoryIds.length})</SelectItem>
            </SelectContent>
          </Select>
          <Button 
            className="bg-gradient-to-r from-red-700 to-red-500 hover:from-red-800 hover:to-red-600"
            onClick={handleBulkDelete}
            disabled={selectedCategoryIds.length === 0 || bulkDeleteMutation.isPending}
          >
            Apply
          </Button>
          <Button onClick={() => setLocation("/categories/new")}>
            <Plus className="mr-2 h-4 w-4" />
            Add Category
          </Button>
        </div>
      </div>

      <Card className="rounded-lg shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>All Categories</CardTitle>
          <Badge variant="outline">{categories.length} items</Badge>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="py-12 text-center text-muted-foreground">Loading categories...</div>
          ) : categories.length === 0 ? (
            <div className="py-12 text-center">
              <p className="text-muted-foreground mb-4">No categories yet</p>
              <Button onClick={() => setLocation("/categories/new")}>
                <Plus className="mr-2 h-4 w-4" />
                Create Your First Category
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <Checkbox 
                      checked={categories.length > 0 && selectedCategoryIds.length === categories.length} 
                      onCheckedChange={(checked) => 
                        setSelectedCategoryIds(checked ? categories.map(c => c.id) : [])
                      } 
                    />
                  </TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="hidden md:table-cell">Content Count</TableHead>
                  <TableHead className="w-[220px] text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {categories.map((category) => {
                  return (
                    <TableRow key={category.id}>
                      <TableCell>
                        <Checkbox 
                          checked={selectedCategoryIds.includes(category.id)}
                          onCheckedChange={(checked) => 
                            setSelectedCategoryIds(prev => 
                              checked 
                                ? [...prev, category.id] 
                                : prev.filter(id => id !== category.id)
                            )
                          }
                        />
                      </TableCell>
                      <TableCell>
                        <div className="min-w-0">
                          <p className="font-medium">{category.name}</p>
                          {category.description ? (
                            <p className="text-sm text-muted-foreground mt-1">{category.description}</p>
                          ) : null}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={category.active ? "default" : "outline"}>
                          {category.active ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        <Badge variant="outline">{category.contentCount}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setLocation(`/categories/${category.id}/shows`)}
                            aria-label={`View shows in ${category.name}`}
                          >
                            <Film className="h-4 w-4 mr-1" />
                            Shows
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => setLocation(`/categories/${category.id}`)}
                            aria-label={`Edit ${category.name}`}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-destructive hover:text-destructive"
                            onClick={() => handleDelete(category)}
                            disabled={deleteMutation.isPending || deletingId === category.id}
                            aria-label={`Delete ${category.name}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
      {!isLoading && categories.length > 0 && (
        <div className="px-6 py-4 flex items-center justify-between text-muted-foreground text-sm border-t border-zinc-700 bg-zinc-800/50 rounded-lg">
          <div className="flex items-center gap-2">
            <span>Show</span>
            <Select value={itemsPerPage.toString()} onValueChange={handleItemsPerPageChange}>
              <SelectTrigger className="w-[100px] bg-zinc-800 border-zinc-700 h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-zinc-800 border-zinc-700">
                <SelectItem value="10">10</SelectItem>
                <SelectItem value="25">25</SelectItem>
                <SelectItem value="50">50</SelectItem>
              </SelectContent>
            </Select>
            <span>entries</span>
          </div>
          <div className="flex items-center gap-2">
            <span>Showing {((pagination.page - 1) * pagination.limit) + 1} to {Math.min(pagination.page * pagination.limit, pagination.total)} of {pagination.total} entries</span>
            <Button 
              variant="ghost" 
              size="sm" 
              className="bg-zinc-800 border-zinc-700 h-8"
              onClick={() => handlePageChange(pagination.page - 1)}
              disabled={pagination.page === 1}
            >
              Previous
            </Button>
            {Array.from({ length: Math.min(pagination.pages, 5) }, (_, i) => {
              const pageNum = i + 1;
              return (
                <Button
                  key={pageNum}
                  variant="ghost"
                  size="sm"
                  className={pageNum === pagination.page ? "bg-gradient-to-r from-red-700 to-red-500 hover:from-red-800 hover:to-red-600 h-8" : "bg-zinc-800 border-zinc-700 h-8"}
                  onClick={() => handlePageChange(pageNum)}
                >
                  {pageNum}
                </Button>
              );
            })}
            <Button 
              variant="ghost" 
              size="sm" 
              className="bg-zinc-800 border-zinc-700 h-8"
              onClick={() => handlePageChange(pagination.page + 1)}
              disabled={pagination.page === pagination.pages}
            >
              Next
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
